from django.test import TestCase
from django.urls import reverse

from .models import Category, Product


class CatalogViewTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.category = Category.objects.create(name="Напитки")
        cls.other_category = Category.objects.create(name="Еда")
        cls.tea = Product.objects.create(
            category=cls.category,
            name="Зелёный чай",
            description="Чай листовой",
            price="12.50",
            stock=8,
        )
        cls.coffee = Product.objects.create(
            category=cls.category,
            name="Кофе",
            description="Молотый кофе",
            price="25.00",
            stock=5,
        )
        cls.food = Product.objects.create(
            category=cls.other_category,
            name="Сэндвич",
            description="Сэндвич с сыром",
            price="18.00",
            stock=3,
        )
        cls.out_of_stock = Product.objects.create(
            category=cls.category,
            name="Нет в наличии",
            price="5.00",
            stock=0,
        )
        cls.inactive = Product.objects.create(
            category=cls.category,
            name="Скрытый товар",
            price="7.00",
            stock=4,
            is_active=False,
        )

    def test_catalog_page_opens(self):
        response = self.client.get(reverse("home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Зелёный чай")

    def test_search_uses_name_and_description(self):
        response = self.client.get(reverse("home"), {"q": "листовой"})
        self.assertContains(response, "Зелёный чай")
        self.assertNotContains(response, "Сэндвич")

    def test_category_filter(self):
        response = self.client.get(
            reverse("home"), {"category": self.other_category.pk}
        )
        self.assertContains(response, "Сэндвич")
        self.assertNotContains(response, "Зелёный чай")

    def test_price_range_filter(self):
        response = self.client.get(
            reverse("home"), {"min_price": "10", "max_price": "20"}
        )
        self.assertContains(response, "Зелёный чай")
        self.assertContains(response, "Сэндвич")
        self.assertNotContains(response, "Кофе")

    def test_sort_by_price_ascending(self):
        response = self.client.get(reverse("home"), {"sort": "price_asc"})
        products = list(response.context["products"])
        self.assertEqual(
            [product.name for product in products],
            ["Зелёный чай", "Сэндвич", "Кофе"],
        )

    def test_out_of_stock_and_inactive_products_are_hidden(self):
        response = self.client.get(reverse("home"))
        self.assertNotContains(response, "Нет в наличии")
        self.assertNotContains(response, "Скрытый товар")

    def test_product_detail_page(self):
        response = self.client.get(
            reverse("product_detail", args=[self.tea.pk])
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Зелёный чай")
        self.assertContains(response, "12,50")

    def test_inactive_product_detail_returns_404(self):
        response = self.client.get(
            reverse("product_detail", args=[self.inactive.pk])
        )
        self.assertEqual(response.status_code, 404)
