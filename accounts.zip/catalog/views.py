from decimal import Decimal, InvalidOperation

from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, render

from .models import Category, Product


SORT_OPTIONS = {
    "name": ("name", "id"),
    "price_asc": ("price", "name", "id"),
    "price_desc": ("-price", "name", "id"),
    "newest": ("-created_at", "id"),
}


def _parse_price(value, label, errors):
    """Проверяет цену из GET-параметра и возвращает Decimal или None."""
    if not value:
        return None

    try:
        price = Decimal(value)
        if not price.is_finite() or price < 0:
            raise InvalidOperation
        return price
    except (InvalidOperation, ValueError):
        errors.append(f"{label}: укажите неотрицательное число.")
        return None


def home(request):
    """Каталог с поиском, фильтрами, сортировкой и постраничным выводом."""
    products = Product.objects.filter(
        is_active=True,
        category__is_active=True,
        stock__gt=0,
    ).select_related("category")

    categories = Category.objects.filter(is_active=True).order_by("name")

    query = request.GET.get("q", "").strip()
    category_id = request.GET.get("category", "").strip()
    min_price_raw = request.GET.get("min_price", "").strip()
    max_price_raw = request.GET.get("max_price", "").strip()
    sort = request.GET.get("sort", "name").strip()

    if query:
        products = products.filter(
            Q(name__icontains=query) | Q(description__icontains=query)
        )

    if category_id.isdigit():
        products = products.filter(category_id=int(category_id))
    else:
        category_id = ""

    filter_errors = []
    min_price = _parse_price(min_price_raw, "Минимальная цена", filter_errors)
    max_price = _parse_price(max_price_raw, "Максимальная цена", filter_errors)

    if min_price is not None and max_price is not None and min_price > max_price:
        filter_errors.append(
            "Минимальная цена не может быть больше максимальной."
        )
        min_price = None
        max_price = None
        min_price_raw = ""
        max_price_raw = ""

    if min_price is not None:
        products = products.filter(price__gte=min_price)
    if max_price is not None:
        products = products.filter(price__lte=max_price)

    if sort not in SORT_OPTIONS:
        sort = "name"
    products = products.order_by(*SORT_OPTIONS[sort])

    paginator = Paginator(products, 12)
    page_obj = paginator.get_page(request.GET.get("page"))

    pagination_params = request.GET.copy()
    pagination_params.pop("page", None)

    return render(request, "home.html", {
        "products": page_obj.object_list,
        "page_obj": page_obj,
        "categories": categories,
        "search_query": query,
        "selected_category": category_id,
        "min_price": min_price_raw,
        "max_price": max_price_raw,
        "selected_sort": sort,
        "filter_errors": filter_errors,
        "total_products": paginator.count,
        "pagination_query": pagination_params.urlencode(),
    })


def product_detail(request, pk):
    """Подробная страница активного товара из активной категории."""
    product = get_object_or_404(
        Product.objects.select_related("category"),
        pk=pk,
        is_active=True,
        category__is_active=True,
    )
    return render(request, "product_detail.html", {"product": product})
